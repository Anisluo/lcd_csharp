$ErrorActionPreference = 'Stop'

function Update-FileText {
    param(
        [string]$Path,
        [scriptblock]$Updater
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "File not found: $Path"
    }

    $old = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    $new = & $Updater $old

    if ($null -eq $new -or $new -eq $old) {
        Write-Host "No change (already applied or anchor not matched): $Path"
        return
    }

    Set-Content -LiteralPath $Path -Value $new -Encoding UTF8
    Write-Host "Updated: $Path"
}

function Insert-AfterFirstRegex {
    param(
        [string]$Text,
        [string]$Pattern,
        [string]$InsertText,
        [string]$ErrorMessage
    )

    $m = [regex]::Match($Text, $Pattern, [System.Text.RegularExpressions.RegexOptions]::Multiline)
    if (-not $m.Success) { throw $ErrorMessage }
    $pos = $m.Index + $m.Length
    return $Text.Insert($pos, $InsertText)
}

function Replace-FirstRegex {
    param(
        [string]$Text,
        [string]$Pattern,
        [string]$Replacement,
        [string]$ErrorMessage
    )

    $m = [regex]::Match($Text, $Pattern, [System.Text.RegularExpressions.RegexOptions]::Multiline -bor [System.Text.RegularExpressions.RegexOptions]::Singleline)
    if (-not $m.Success) { throw $ErrorMessage }
    return $Text.Substring(0, $m.Index) + $Replacement + $Text.Substring($m.Index + $m.Length)
}

function Find-ProjectRoot {
    param([string]$StartDir)

    $dir = $StartDir
    while ($dir) {
        $candidate1 = Join-Path $dir 'LCD\Data\Project.cs'
        if (Test-Path -LiteralPath $candidate1) { return $dir }

        $candidate2 = Join-Path $dir 'Data\Project.cs'
        $candidate3 = Join-Path $dir 'View\DeviceView.xaml'
        if ((Test-Path -LiteralPath $candidate2) -and (Test-Path -LiteralPath $candidate3)) {
            return (Split-Path -Parent $dir)
        }

        $parent = Split-Path -Parent $dir
        if ($parent -eq $dir) { break }
        $dir = $parent
    }

    throw "Project root not found from: $StartDir"
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Find-ProjectRoot -StartDir $scriptDir

$projectCs    = Join-Path $root 'LCD\Data\Project.cs'
$deviceViewXaml = Join-Path $root 'LCD\View\DeviceView.xaml'
$movCtrlCs    = Join-Path $root 'LCD\Ctrl\MovCtrl.cs'

# -----------------------------------------------------------------------
# 1. Project.cs  -- add IsFlipped field to Config class
# -----------------------------------------------------------------------
Update-FileText -Path $projectCs -Updater {
    param($text)
    if ($text -match 'public bool IsFlipped') { return $text }
    Insert-AfterFirstRegex $text `
        '(?m)^\s*public int VReverse;\s*\r?\n' `
        "        public bool IsFlipped; // 仪器固定，翻转式`r`n" `
        'VReverse anchor not found in Project.cs'
}

# -----------------------------------------------------------------------
# 2. DeviceView.xaml  -- add CheckBox to bottom StackPanel
# -----------------------------------------------------------------------
Update-FileText -Path $deviceViewXaml -Updater {
    param($text)
    if ($text -match '仪器固定，翻转式') { return $text }
    # Match the closing </StackPanel> that follows the Clear2 button
    Replace-FirstRegex $text `
        '(?s)(<Button[^/]*/Clear2[^/]*/[^>]*>\s*</Button>|<Button[^>]+Clear2[^>]+/>)(\s*</StackPanel>)' `
        ('$1' + "`r`n                <CheckBox Content=`"仪器固定，翻转式`" VerticalAlignment=`"Center`" Margin=`"20,0,0,0`"`r`n                          IsChecked=`"{Binding IsFlipped, Source={x:Static app1:Project.cfg}, Mode=TwoWay}`"/>" + '$2') `
        'Clear2 button / StackPanel anchor not found in DeviceView.xaml'
}

# -----------------------------------------------------------------------
# 3. MovCtrl.cs  -- MoveXAxisDown: inject dir variable and replace usages
# -----------------------------------------------------------------------
Update-FileText -Path $movCtrlCs -Updater {
    param($text)
    if ($text -match 'MoveXAxisDown[\s\S]{0,600}IsFlipped') { return $text }
    Replace-FirstRegex $text `
        '(?s)(public void MoveXAxisDown\(EnumMoveSpeed speed\)\s*\{[^}]*?if \(!axe\.IsEnable\) \{ return; \}\s*)(\r?\n)([\s\S]*?MoveAxisNoWait\(axe, speed, axe\.direction\);\s*\}\s*\})' `
        ('$1$2            int dir = Project.cfg.IsFlipped ? -axe.direction : axe.direction;$2' + '$3') `
        'MoveXAxisDown anchor not found in MovCtrl.cs'
}

# Replace axe.direction with dir inside MoveXAxisDown body
Update-FileText -Path $movCtrlCs -Updater {
    param($text)
    # Only replace inside MoveXAxisDown — find the block and do scoped replacements
    $pattern = '(?s)(public void MoveXAxisDown\(EnumMoveSpeed speed\)\s*\{[\s\S]*?int dir = Project\.cfg\.IsFlipped \? -axe\.direction : axe\.direction;[\s\S]*?)(MoveAxisNoWaitByVector\(axe, speed, axe\.direction\))([\s\S]*?)(MoveAxisNoWait\(axe, speed, axe\.direction\))([\s\S]*?MoveXAxisDown[\s\S]{0,20}?\})'
    if (-not ($text -match '(?s)public void MoveXAxisDown[\s\S]{0,800}MoveAxisNoWaitByVector\(axe, speed, axe\.direction\)')) { return $text }

    # Scoped: replace only in MoveXAxisDown block
    $m = [regex]::Match($text, '(?s)(public void MoveXAxisDown\(EnumMoveSpeed speed\)\s*\{)([\s\S]*?)(\n        \})', [System.Text.RegularExpressions.RegexOptions]::None)
    if (-not $m.Success) { return $text }
    $blockOld = $m.Value
    $blockNew = $blockOld -replace 'MoveAxisNoWaitByVector\(axe, speed, axe\.direction\)', 'MoveAxisNoWaitByVector(axe, speed, dir)' `
                          -replace 'MoveAxisNoWait\(axe, speed, axe\.direction\)', 'MoveAxisNoWait(axe, speed, dir)'
    if ($blockNew -eq $blockOld) { return $text }
    return $text.Substring(0, $m.Index) + $blockNew + $text.Substring($m.Index + $m.Length)
}

# -----------------------------------------------------------------------
# 4. MovCtrl.cs  -- MoveYAxiesDown: inject dir variable and replace usages
# -----------------------------------------------------------------------
Update-FileText -Path $movCtrlCs -Updater {
    param($text)
    if ($text -match 'MoveYAxiesDown[\s\S]{0,600}IsFlipped') { return $text }
    Replace-FirstRegex $text `
        '(?s)(public void MoveYAxiesDown\(EnumMoveSpeed speed\)\s*\{[^}]*?if \(!axe\.IsEnable\) \{ return; \}\s*)(\r?\n)([\s\S]*?MoveAxisNoWait\(axe, speed, axe\.direction\);\s*\}\s*\})' `
        ('$1$2            int dir = Project.cfg.IsFlipped ? -axe.direction : axe.direction;$2' + '$3') `
        'MoveYAxiesDown anchor not found in MovCtrl.cs'
}

Update-FileText -Path $movCtrlCs -Updater {
    param($text)
    $m = [regex]::Match($text, '(?s)(public void MoveYAxiesDown\(EnumMoveSpeed speed\)\s*\{)([\s\S]*?)(\n        \})', [System.Text.RegularExpressions.RegexOptions]::None)
    if (-not $m.Success) { return $text }
    $blockOld = $m.Value
    if (-not ($blockOld -match 'IsFlipped')) { return $text }
    $blockNew = $blockOld -replace 'MoveAxisNoWaitByVector\(axe, speed, axe\.direction\)', 'MoveAxisNoWaitByVector(axe, speed, dir)' `
                          -replace 'MoveAxisNoWait\(axe, speed, axe\.direction\)', 'MoveAxisNoWait(axe, speed, dir)'
    if ($blockNew -eq $blockOld) { return $text }
    return $text.Substring(0, $m.Index) + $blockNew + $text.Substring($m.Index + $m.Length)
}

Write-Host ""
Write-Host "Flip update (仪器固定，翻转式) applied."
Write-Host "Please rebuild the project on the target machine."
